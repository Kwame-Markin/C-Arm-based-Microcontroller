/* 
 In this project 8 LEDs are connecte dto PORT C of the Nucleo-F411RE
development board. Random numbers are generated between 0 and 255 (all
LEDs OFF or all LEDs ON) and the LEDs then turn ON and OFF by sending
these numbers to PORT C every 250ms. The net effect is that the LEDs
look like Christmas light
Author: Kwame Markin
Date : December 30, 2023
File : Unknown
 *
 */

#include "mbed.h"

#define WAIT_TIME_MS 250 
BusOut Random_LEDS(PC_0,PC_1,PC_2,PC_3,PC_4,PC_5,PC_6,PC_7);

int main()
{   
    int Number;
    while (1)
    {
        Number = rand();
        Random_LEDS = Number;
        thread_sleep_for(WAIT_TIME_MS);
    }
}

/*****************************************************************************
BINARY EVENT COUNTER WITH LEDS
==============================
In this program 8 LEDs are connected to lower byte of PORT C. The program
simulates an event counter such that when the User button is pressed a
count is incremented by one and is then displayed on the LEDs.
Author: Kwame Markin
Date : December 31, 2023
File : Events
***************************************************************************/

#include "mbed.h"

#define WAIT_TIME_MS 500 
//DigitalOut led1(LED1);
BusOut LEDS(PC_0,PC_1,PC_2,PC_3,PC_4,PC_5,PC_6,PC_7);
DigitalIn button(BUTTON1);

int main()
{
    int Cnt = 0;
    LEDS = 0; // all LEDs are off at the beginning
    while (1)
    {
        if (button == 0)
        {
            Cnt++;
            LEDS = Cnt;
            while (button == 0);
        }
        //thread_sleep_for(WAIT_TIME_MS);
    }
}
